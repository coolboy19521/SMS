from django.contrib import admin
from .models import Museum, Exhibit

admin.site.register(Museum)
admin.site.register(Exhibit)